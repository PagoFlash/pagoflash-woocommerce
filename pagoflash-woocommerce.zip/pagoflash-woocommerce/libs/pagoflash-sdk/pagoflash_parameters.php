<?php 
/**
  * @author Argenis Fontalvo [argenisfd@gmail.com]
  * @version 0.0.1
  * 
  * IMPORTANTE: No modifique los valores de este archivo   
  *
  */

return array(
	'prod'=>array(
		'domain'=>"https://app.pagoflash.com"
	),
	'dev'=>array(
		'domain'=>'http://app-test2.pagoflash.com'
	)
);