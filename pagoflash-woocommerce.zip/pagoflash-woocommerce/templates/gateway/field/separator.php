<?php
/* @var $options array */

if (false === defined('ABSPATH'))
{
  header('Location: http://www.enebruskemlem.com.ve');
  exit;
}
?>
<!-- separator -->
<tr>
  <td colspan="2"><hr/></td>
</tr>
<!--/ separator -->